Code will excute only if test file access given as below


->For Testing CSV file upload it on github repository and then open it and view as raw 
then paste link of raw view of csv file in df function of python code

->Install Anaconda 
Open Jupyter Notebook

->Libraries to install in Jupyter Notebook of Anaconda
import numpy as np
import pandas as pd
!pip install tensorflow
import pandas_datareader as pdr
from sklearn.preprocessing import MinMaxScaler
import numpy
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.layers import LSTM
import tensorflow as tf
import math
from sklearn.metrics import mean_squared_error
from numpy import array

